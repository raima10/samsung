import React from 'react';
import { Route, Routes, NavLink } from 'react-router-dom';

import AboutUS from '../AboutUs/AboutUs'
import Cart from '../Cart/Cart'
import '../Menu/Menu.css'
import Samsung from '../SamsungFol/Samsung';


function Menu({samsungItems,cart,addToCart,removeFromCart,handleCartClearance}) {
    return (
        <>
            <div className='welcome'>Welcome to Samsung</div>
            <br></br>
            
            <div className='tool'>
            <ul>
                <li>
                    <NavLink to='/aboutus' className="nav-link">About Us</NavLink>
                </li>
                <li>
                    <NavLink to='/samsung' className="nav-link text-dark">Products List</NavLink>
                </li>
                <li>
                    <NavLink to='/cart' className="nav-link">Cart</NavLink>
                </li>
            </ul>

            </div>
           
            <Routes>
                <Route exact path='/aboutus' element={<AboutUS />} />
                <Route exact path='/cart' element={<Cart 
                cart={cart}
                addToCart={addToCart}
                removeFromCart={removeFromCart}
                handleCartClearance={handleCartClearance}
                />} />
                <Route path='/samsung' element={
                <Samsung 
                    addToCart={addToCart}
                    samsungItems={samsungItems}
                />} />
            </Routes>




        </>
    );
}

export default Menu;