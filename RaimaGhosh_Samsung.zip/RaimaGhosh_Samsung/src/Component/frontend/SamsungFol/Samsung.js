import React from 'react';
import Phones from './Phones';


function Samsung({samsungItems, addToCart}) {
    return (

        <div style={{textAlign:'center'}}>
            <div className='product'>
            {samsungItems.map((prodVar, index)=>{
                return(
                    
                    <Phones 
                    key={index}
                    img={prodVar.imgsrc}
                    name={prodVar.name}
                    price={prodVar.price}
                    type={prodVar.type}
                    addToCart={() => {addToCart(prodVar)}}
                    />
                );

            })}
                

            </div>

     
        </div>
    );
}

export default Samsung;