import React from 'react';
import './Product.css'

function Phones(props, product) {
    return ( 
        <div className=''>
            <div className='card'>
                <img className='phone-img' src={props.img} alt=''/>
            </div>
             <span>{props.name}</span>
            <br></br>
            <span>{props.type}</span>
            <span>Rs. {props.price}</span>
            <br></br>
            <br></br>
            <button className='btn' onClick={() => {props.addToCart(product)}}>Add Product</button>

        </div>
     );
}

export default Phones;