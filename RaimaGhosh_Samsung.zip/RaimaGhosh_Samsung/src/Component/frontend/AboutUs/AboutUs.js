import React from 'react';
import '../AboutUs/AboutUs.css'

function AboutUS() {
    return (

        <div>
            <div className='heading'>
            <h1>Know about Samsung</h1>
            </div>
            
            <p>Samsung Group, or simply Samsung (Korean: 삼성 [samsʌŋ]) (stylized as SΛMSUNG), is a South Korean multinational manufacturing conglomerate headquartered in Samsung Town, Seoul, South Korea.[1] It comprises numerous affiliated businesses,[1] most of them united under the Samsung brand, and is the largest South Korean chaebol (business conglomerate). As of 2020, Samsung has the eighth highest global brand value.[4]

                Samsung was founded by Lee Byung-chul in 1938 as a trading company. Over the next three decades, the group diversified into areas including food processing, textiles, insurance, securities, and retail. Samsung entered the electronics industry in the late 1960s and the construction and shipbuilding industries in the mid-1970s; these areas would drive its subsequent growth. Following Lee's death in 1987, Samsung was separated into five business groups – Samsung Group, Shinsegae Group, CJ Group and Hansol Group, and JoongAng Group.

                Notable Samsung industrial affiliates include Samsung Electronics (the world's largest information technology company, consumer electronics maker and chipmaker measured by 2017 revenues),[5][6] Samsung Heavy Industries (the world's second largest shipbuilder measured by 2010 revenues),[7] and Samsung Engineering and Samsung C&T Corporation (respectively the world's 13th and 36th largest construction companies).[8] Other notable subsidiaries include Samsung Life Insurance (the world's 14th largest life insurance company),[9] Samsung Everland (operator of Everland Resort, the oldest theme park in South Korea)[10] and Cheil Worldwide (the world's 15th largest advertising agency, as measured by 2012 revenues).[11][12]

                Etymology
                According to Samsung's founder, the meaning of the Korean hanja word Samsung (三星) is "three stars". The word "three" represents something "big, numerous and powerful",[13] while "stars" means "everlasting" or "eternal", like stars in the sky.[14][15]

                History
                1938–1970

                Lee Byung-chul, founder of Samsung
                In 1938, during Japanese-ruled Korea, Lee Byung-chul (1910–1987) of a large landowning family in the Uiryeong county moved to nearby Daegu city and founded Mitsuboshi Trading Company (株式会社三星商会 (Kabushiki gaisha Mitsuboshi Shōkai)), or Samsung Sanghoe (주식회사 삼성상회). Samsung started out as a small trading company with forty employees located in Su-dong (now Ingyo-dong).[16] It dealt in dried-fish,[16] locally-grown groceries and noodles. The company prospered and Lee moved its head office to Seoul in 1947. When the Korean War broke out, he was forced to leave Seoul. He started a sugar refinery in Busan named Cheil Jedang. In 1954, Lee founded Cheil Mojik and built the plant in Chimsan-dong, Daegu. It was the largest woollen mill ever in the country.[citation needed]

                Samsung diversified into many different areas. Lee sought to establish Samsung as a leader in a wide range of industries. Samsung moved into lines of business such as insurance, securities, and retail.

                In 1947, Cho Hong-jai, the Hyosung group's founder, jointly invested in a new company called Samsung Mulsan Gongsa, or the Samsung Trading Corporation, with the Samsung's founder Lee Byung-chul. The trading firm grew to become the present-day Samsung C&T Corporation. After a few years, Cho and Lee separated due to differences in management style. Cho wanted a 30 equity share. Samsung Group was separated into Samsung Group and Hyosung Group, Hankook Tire and other businesses.[17][18]

                In the late 1960s, Samsung Group entered the electronics industry. It formed several electronics-related divisions, such as Samsung Electronics Devices, Samsung Electro-Mechanics, Samsung Corning and Samsung Semiconductor & Telecommunications, and opened the facility in Suwon. Its first product was a black-and-white television set.</p>
        </div>
    );
}

export default AboutUS;