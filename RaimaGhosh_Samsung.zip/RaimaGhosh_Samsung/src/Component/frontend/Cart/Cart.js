import React from 'react';
import '../Cart/Cart.css'



function Cart({ cart, addToCart, removeFromCart, handleCartClearance }) {

    const totalprice = cart.reduce((price, item) => price + item.quantity * item.price, 0);

    return (
        <div className='cart-items'>
            <h1 className='cart-items-header'>Cart Items</h1>
            <div className='clear-cart'>
                {cart.length >= 1 && (
                    <button className='btn btn-outline-dark' onClick={handleCartClearance}>Clear Cart</button>
                )}
            </div>



            {cart.length === 0 &&
                <div className='cart-items-empty'>
                    No items are Added.
                </div>
            }



            <div>
                {cart.map((item) => {
                    return (
                        <div key={item.key} className="cart-items-list">
                            <img className='cart-items-image'
                                src={item.imgsrc}
                                alt={item.name}
                            />



                            <div className='cart-items-name'>
                                {item.name}
                            </div>



                            <div className='cart-items-function'>
                                <button className='btn btn-outline-dark m-1 px-2.5' onClick={() => addToCart(item)}>+</button>
                                <button className='btn btn-outline-dark px-2.5' onClick={() => removeFromCart(item)}>-</button>
                            </div>



                            <div className='cart-items-price'>
                                {item.quantity} * Rs. {item.price}
                            </div>
                        </div>
                    );
                })



                }
            </div>
            <div className='cart-items-total-price-name'>
                Total Price:
                <span className='cart-items-total-price'> Rs. {totalprice}</span>
            </div>
        </div>

    );

}



export default Cart;