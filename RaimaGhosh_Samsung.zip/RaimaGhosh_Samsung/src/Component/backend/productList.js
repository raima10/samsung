export const productList = {
    samsungItems:
        [
            {
                key: 1,
                imgsrc: 'https://images.samsung.com/is/image/samsung/p6pim/in/sm-s911bzecins/gallery/in-galaxy-s23-s911-sm-s911bzecins-thumb-535265855?$172_172_PNG$',
                name: 'Galaxy S23',
                price: 79999
            },

            {
                key: 2,
                imgsrc: 'https://images.samsung.com/is/image/samsung/p6pim/in/sm-a146bdrhins/gallery/in-galaxy-a14-5g-sm-a146-446752-sm-a146bdrhins-thumb-534858282?$172_172_PNG$',
                name: 'Galaxy A14',
                price: 19990
            },

            {
                key: 3,
                imgsrc: 'https://images.samsung.com/is/image/samsung/p6pim/in/sm-a236elbgins/gallery/in-galaxy-a23-5g-sm-a236-sm-a236elbgins-thumb-534854424?$172_172_PNG$',
                name: 'Galaxyb A23',
                price: 88990
            },

            {
                key: 4,
                imgsrc: 'https://images.samsung.com/is/image/samsung/p6pim/in/sm-a047fzcgins/gallery/in-galaxy-a04s-a047-sm-a047fzcgins-thumb-533977914?$172_172_PNG$',
                name: 'Galaxy A04',
                price: 77896
            },

            {
                key: 5,
                imgsrc: 'https://images.samsung.com/is/image/samsung/p6pim/in/sm-m045fdbgins/gallery/in-galaxy-m04-4gb-64gb-sm-m045fdbgins-thumb-534598588?$172_172_PNG$',
                name: 'Galaxy M04',
                price: 55432
            }
        ]
}