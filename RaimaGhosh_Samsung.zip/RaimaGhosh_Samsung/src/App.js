
import './App.css';
import Menu from './Component/frontend/Menu/Menu';
import React, { useState } from 'react';
import { productList } from './Component/backend/productList';


function App() {
  const { samsungItems } = productList;

  const [cart, setCart] = useState([]);



  const addToCart = (product) => {

    const samsungExist = cart.find((item) => item.key === product.key);

    if (samsungExist) {
      console.log(samsungExist);
      setCart(
        cart.map((item) =>
          item.key === product.key
            ? { ...samsungExist, quantity: samsungExist.quantity + 1 } : item)
      );
    }
    else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }

  }



  const removeFromCart = (product) => {

    const samsungExist = cart.find((item) => item.key === product.key);



    if (samsungExist.quantity === 1) {

      setCart(cart.filter((item) => item.key !== product.key));

    }

    else {

      setCart(

        cart.map((item) =>

          item.key === product.key

            ? { ...samsungExist, quantity: samsungExist.quantity - 1 } : item)

      );

    }

  }



  const handleCartClearance = () => {

    setCart([]);

  }

  return (





    <div className="App">
      <Menu
        samsungItems={samsungItems} cart={cart}

        addToCart={addToCart}

        removeFromCart={removeFromCart}

        handleCartClearance={handleCartClearance}
      />


    </div>
  );
}

export default App;
